﻿using System.ComponentModel.DataAnnotations;

namespace CRUD_18_12_22.Models
{
    public class MenuItem
    {
        [Key]
        public int Id { get; set; }
        public string DishName { get; set; }
        public int Roti { get; set; }
        public bool DineIn { get; set; }
    }
}
